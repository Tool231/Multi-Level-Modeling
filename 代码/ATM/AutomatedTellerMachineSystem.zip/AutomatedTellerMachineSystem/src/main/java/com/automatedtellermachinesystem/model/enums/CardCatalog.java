package com.automatedtellermachinesystem.model.enums;

public enum CardCatalog {
    CREDIT, DEPOSIT;
}
