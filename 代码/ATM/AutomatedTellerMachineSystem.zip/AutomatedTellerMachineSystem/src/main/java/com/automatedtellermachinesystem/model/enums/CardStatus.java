package com.automatedtellermachinesystem.model.enums;

public enum CardStatus {
    NORMAL, SUSPEND, CANCEL;
}
