INSERT INTO USER (id, address, name, user_id) VALUES (1, 'Ankara', 'yigit', 23);

INSERT INTO BANK_CARD(id, balance, card_catalog, card_id, card_status, password, user_id) VALUES (1, 200, 'CREDIT', 1, 'NORMAL', 1234, 1);
