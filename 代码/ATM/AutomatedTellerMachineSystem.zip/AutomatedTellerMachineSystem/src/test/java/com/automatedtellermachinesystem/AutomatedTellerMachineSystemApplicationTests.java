package com.automatedtellermachinesystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomatedTellerMachineSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
